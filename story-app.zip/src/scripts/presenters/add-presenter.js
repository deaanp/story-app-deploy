import { addNewStory } from '../data/story-api';
import { getAuthData } from '../auth/auth-service';
import { openDB } from 'idb';
import { StoryDB } from '../data/idb';

export default class AddPresenter {
  constructor({ view, camera, map }) {
    this.view = view;
    this.camera = camera;
    this.map = map;
    this.imageBlob = null;
    this.lat = null;
    this.lon = null;
  }

  async init() {
    const auth = getAuthData();
    if (!auth) {
      location.hash = '#/login';
      return;
    }

    this._setupMap();
    this._setupViewListeners(auth.token);
  }

  _setupMap() {
    this.map.onClick((lat, lon) => {
      this.lat = lat;
      this.lon = lon;
    });
  }

  _setupViewListeners(token) {
    this.view.onFileSelected((file) => {
      if (file.size > 1024 * 1024) {
        this.view.showWarning('File too large!', 'Image must not exceed 1MB');
        return;
      }
      this.imageBlob = file;
      this.view.showPreview(file);
    });

    this.view.onOpenCamera(async () => {
      this.view.resetForm();
      await this.camera.start();
      this.view.toggleCameraMode(true);
    });

    this.view.onCapturePhoto(async () => {
      const blob = await this.camera.capture();
      this.imageBlob = blob;
      this.view.showPreview(blob);
      this.camera.stop();
      this.view.toggleCameraMode(false);
    });

    this.view.onStopCamera(() => {
      this.camera.stop();
      this.view.toggleCameraMode(false);
    });

    this.view.onRemovePhoto(() => {
      this.imageBlob = null;
      this.view.resetForm();
      this.view.showMessage('Photo removed', 'info');
    });

    this.view.onSubmit(async ({ title, desc }) => {
      if (!desc || !title || !this.imageBlob) {
        this.view.showWarning(
          'Incomplete Form',
          'Please fill out all fields and select a photo!'
        );
        return;
      }

      if (!this.lat || !this.lon) {
        this.view.showInfo(
          'Location Missing',
          'Click on the map to set the story location!'
        );
        return;
      }

      try {
        const res = await addNewStory({
          token,
          description: `${title} = ${desc}`,
          photo: this.imageBlob,
          lat: this.lat,
          lon: this.lon,
        });

        if (res.error) {
          this.view.showError('Failed to Add Story', res.message);
          return;
        }

        if (res.story) {
          await StoryDB.putStory(res.story);
        }

        this.view.showSuccess(
          'Story Added!',
          'Your new story has been successfully posted'
        );
        this.view.resetForm();

        setTimeout(() => {
          location.hash = '#/';
        }, 1000);
      } catch (err) {
        console.warn('[AddPresenter] Offline detected, saving story locally...', err);

        const db = await openDB('story-db', 2);
        const tx = db.transaction('pending-stories', 'readwrite');
        const store = tx.objectStore('pending-stories');

        const tempId = Date.now();
        await store.put({
          tempId,
          title,
          desc,
          imageBlob: this.imageBlob,
          lat: this.lat,
          lon: this.lon,
          token,
        });
        await tx.done;

        await StoryDB.putStory({
          id: `tempt-${tempId}`,
          name: title,
          description: desc,
          createdAt: new Date().toISOString(),
          photoUrl: './images/offline-placeholder.png',
        })

        if ('serviceWorker' in navigator && 'SyncManager' in window) {
          const registration = await navigator.serviceWorker.ready;
          await registration.sync.register('sync-pending-stories');
          console.log('[AddPresenter] Story saved locally & sync registered');
          this.view.showInfo(
            'Offline Mode',
            'Your story will be uploaded once you’re online'
          );
        } else {
          this.view.showError(
            'Offline',
            'Your browser does not support background sync'
          );
        }
      }
    });
  }
}
