import { getAllStories } from '../data/story-api';
import { getAuthData } from '../auth/auth-service';
import { StoryDB } from '../data/idb';

export default class HomePresenter {
  constructor({ view }) {
    this.view = view;
    this.stories = [];

    this.view.bindSearchFilter(this._handleSearchFilter.bind(this));
  }

  async init() {
    const auth = getAuthData();
    if (!auth) {
      location.hash = '#/login';
      return;
    }

    this.view.showLoading();

    try {
      const localStories = await StoryDB.getAllStories();
      if (localStories.length > 0) {
        this.stories = localStories;
        this.view.renderStories(localStories);
      }

      const res = await getAllStories({ token: auth.token, location: 1 });
      this.stories = res.listStory || [];

      this.view.renderStories(this.stories);

      for (const story of this.stories) {
        await StoryDB.putStory(story);
      }

      if (this.stories.length === 0) {
        this.view.showEmpty();
      }
    } catch (err) {
      console.error('Failed to load stories:', err);
      this.view.showError('Failed to load stories. Please try again.');
    }
  }

  _handleSearchFilter({ query, sort }) {
    let filtered = this.stories.filter(
      (s) =>
        s.name.toLowerCase().includes(query.toLowerCase()) ||
        s.description.toLowerCase().includes(query.toLowerCase())
    );

    if (sort === 'latest') {
      filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    } else {
      filtered.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    }

    this.view.renderStories(filtered);
  }

  _handleRead(id) {
    console.log('story clicked', id);
  }
}
